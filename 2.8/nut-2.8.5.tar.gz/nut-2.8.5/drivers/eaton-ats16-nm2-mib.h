/* eaton_ats16-nm2-mib.h - subdriver to monitor Eaton ATS16 NM2 SNMP devices with NUT
 *
 *  Copyright (C)
 *    2011-2012 Arnaud Quette <arnaud.quette@free.fr>
 *    2016-2017 Eaton (author: Arnaud Quette <ArnaudQuette@Eaton.com>)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef EATON_ATS16_NM2_MIB_H
#define EATON_ATS16_NM2_MIB_H

#include "main.h"
#include "snmp-ups.h"

extern mib2nut_info_t eaton_ats16_nm2;

#endif /* EATON_ATS16_NM2_MIB_H */
